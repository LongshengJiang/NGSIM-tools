export
    PNGFrames,
    SVGFrames

PNGFrames(; fps::Int=24) = Reel.Frames(MIME("image/png"), fps=fps)
SVGFrames(; fps::Int=24) = Reel.Frames(MIME("image/svg"), fps=fps)