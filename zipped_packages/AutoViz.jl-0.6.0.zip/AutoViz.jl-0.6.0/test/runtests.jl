using Base.Test
using AutomotiveDrivingModels
using AutoViz
using NBInclude


nbinclude(Pkg.dir("AutoViz", "doc", "AutoViz.ipynb"))