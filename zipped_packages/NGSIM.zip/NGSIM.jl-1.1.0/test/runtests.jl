using Base.Test
using NGSIM
using NBInclude

nbinclude(joinpath(dirname(@__FILE__), "..", "jnotebooks", "Demo.ipynb"))