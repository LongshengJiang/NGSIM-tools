# Records.jl

A Julia package providing records over time both as lists (`ListRecord`) and queues (`QueueRecord`). Useful for sequential data.

[![Build Status](https://travis-ci.org/sisl/Records.jl.svg?branch=master)](https://travis-ci.org/sisl/Records.jl)
[![Coverage Status](https://coveralls.io/repos/sisl/Records.jl/badge.svg?branch=master&service=github)](https://coveralls.io/github/sisl/Records.jl?branch=master)
