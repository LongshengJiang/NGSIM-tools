using Base.Test
using Records

include("test_listrecords.jl")
include("test_queuerecords.jl")
include("test_frames.jl")
include("test_conversions.jl")
include("test_io.jl")