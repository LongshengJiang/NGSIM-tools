export
        ConvexPolygon,
        CPAMemory,
        CollisionCheckResult,

        LineSegment,

        to_oriented_bounding_box!,
        get_oriented_bounding_box,
        is_colliding,
        is_potentially_colliding,
        get_collision_time,
        get_first_collision,
        get_time_and_dist_of_closest_approach,
        is_collision_free,
        get_distance,
        get_edge,
        get_side,

        CollisionCallback

include("minkowski.jl")